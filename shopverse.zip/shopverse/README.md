# ShopVerse 🛍️ — Full-Stack E-Commerce

A complete Amazon-style e-commerce website built with Flask + HTML/CSS/JS.

## ⚡ Quick Start

```bash
cd shopverse
pip install -r requirements.txt
python app.py
```

Then open → **http://localhost:5000**

## ✨ Features

| Feature | Details |
|---|---|
| 🏠 Homepage | Hero banner, flash deals countdown, category grid, featured products, promo banners, reviews |
| 🛍️ Product Listing | Filter by category, sort by price/rating, grid/list view toggle |
| 📄 Product Detail | Image gallery, qty selector, Add to Cart / Buy Now, related products, reviews tab |
| 🛒 Cart | Add/remove/update qty, promo codes, order summary |
| 💳 Checkout | Shipping form, delivery method selector, 4 payment methods, order summary |
| 🎉 Order Success | Confetti animation, order tracking steps, order ID |
| ❤️ Wishlist | Save/remove products, add to cart from wishlist |
| 🔍 Search | Live autocomplete dropdown in navbar |
| 📱 Responsive | Mobile-friendly on all pages |
| 🎨 Animations | Page load, scroll reveal, hover effects, floating tags, countdown timer |

## 🗂️ Project Structure

```
shopverse/
├── app.py              # Flask server & all API routes
├── requirements.txt    # Dependencies (only Flask)
├── templates/
│   ├── base.html       # Navbar, footer, toast, search
│   ├── index.html      # Homepage
│   ├── products.html   # Product listing + filters
│   ├── product_detail.html  # Product page
│   ├── cart.html       # Shopping cart
│   ├── checkout.html   # Checkout form
│   ├── order_success.html   # Confirmation page
│   └── wishlist.html   # Wishlist
└── static/             # (place custom assets here)
```

## 🔌 API Endpoints

| Method | Route | Description |
|---|---|---|
| GET | `/` | Homepage |
| GET | `/products` | Product listing (filter/sort) |
| GET | `/product/<id>` | Product detail page |
| GET | `/cart` | Cart page |
| POST | `/api/cart/add` | Add item to cart |
| POST | `/api/cart/remove` | Remove item |
| POST | `/api/cart/update` | Update quantity |
| GET | `/api/cart/count` | Get cart item count |
| POST | `/api/wishlist/toggle` | Add/remove wishlist |
| GET | `/wishlist` | Wishlist page |
| GET | `/checkout` | Checkout page |
| POST | `/api/place-order` | Place order |
| GET | `/order-success` | Order confirmation |
| GET | `/api/products/search?q=` | Live search |
| GET/POST | `/api/products/<id>/reviews` | Reviews |
