from flask import Flask, render_template, request, jsonify, session, redirect, url_for
import json, os, uuid
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'shopverse-secret-2024'

# ── In-memory data store ──────────────────────────────────────────────────────

PRODUCTS = [
    {"id":1,"name":"ProMax Wireless Headphones","price":299.99,"original_price":399.99,"category":"Electronics","rating":4.8,"reviews":2341,"image":"🎧","badge":"Best Seller","stock":15,"description":"Immersive 40-hour battery life, active noise cancellation, premium sound quality.","tags":["wireless","audio","premium"]},
    {"id":2,"name":"UltraSlim Laptop 14\"","price":1199.99,"original_price":1499.99,"category":"Electronics","rating":4.7,"reviews":876,"image":"💻","badge":"Hot Deal","stock":8,"description":"Intel i7, 16GB RAM, 512GB SSD, stunning 4K display in a featherlight chassis.","tags":["laptop","work","portable"]},
    {"id":3,"name":"Running Pro Sneakers","price":129.99,"original_price":179.99,"category":"Fashion","rating":4.6,"reviews":5423,"image":"👟","badge":"Top Rated","stock":42,"description":"Engineered mesh upper, responsive cushioning, perfect for long-distance runners.","tags":["shoes","sport","comfort"]},
    {"id":4,"name":"Smart Watch Series X","price":449.99,"original_price":549.99,"category":"Electronics","rating":4.9,"reviews":1204,"image":"⌚","badge":"New","stock":23,"description":"Health monitoring, GPS, 18-hour battery, always-on retina display.","tags":["wearable","fitness","smart"]},
    {"id":5,"name":"Leather Crossbody Bag","price":89.99,"original_price":129.99,"category":"Fashion","rating":4.5,"reviews":934,"image":"👜","badge":"Trending","stock":31,"description":"Genuine Italian leather, multiple compartments, adjustable strap.","tags":["bag","leather","style"]},
    {"id":6,"name":"4K Action Camera","price":349.99,"original_price":449.99,"category":"Electronics","rating":4.7,"reviews":678,"image":"📷","badge":"Popular","stock":12,"description":"Waterproof to 30m, 4K 60fps, built-in stabilization, voice control.","tags":["camera","adventure","video"]},
    {"id":7,"name":"Ergonomic Office Chair","price":499.99,"original_price":699.99,"category":"Home","rating":4.8,"reviews":2109,"image":"🪑","badge":"Editor's Choice","stock":6,"description":"Lumbar support, adjustable armrests, breathable mesh, 8-hour comfort.","tags":["chair","office","ergonomic"]},
    {"id":8,"name":"Premium Coffee Maker","price":199.99,"original_price":269.99,"category":"Home","rating":4.6,"reviews":1567,"image":"☕","badge":"Bestseller","stock":19,"description":"12-cup capacity, built-in grinder, programmable timer, thermal carafe.","tags":["kitchen","coffee","morning"]},
    {"id":9,"name":"Yoga Mat Pro","price":59.99,"original_price":89.99,"category":"Sports","rating":4.7,"reviews":3201,"image":"🧘","badge":"Top Pick","stock":55,"description":"6mm cushioning, non-slip surface, alignment lines, eco-friendly materials.","tags":["yoga","fitness","wellness"]},
    {"id":10,"name":"Bluetooth Speaker 360","price":149.99,"original_price":199.99,"category":"Electronics","rating":4.8,"reviews":1893,"image":"🔊","badge":"Hot","stock":27,"description":"360° surround sound, IPX7 waterproof, 24-hour playtime, party mode.","tags":["audio","portable","party"]},
    {"id":11,"name":"Stainless Steel Cookware Set","price":289.99,"original_price":399.99,"category":"Home","rating":4.6,"reviews":742,"image":"🍳","badge":"Chef's Choice","stock":14,"description":"10-piece set, tri-ply construction, oven safe to 500°F, dishwasher safe.","tags":["cooking","kitchen","premium"]},
    {"id":12,"name":"Men's Slim Fit Suit","price":399.99,"original_price":599.99,"category":"Fashion","rating":4.5,"reviews":456,"image":"🤵","badge":"Luxury","stock":9,"description":"Wool blend, modern cut, fully lined, perfect for formal occasions.","tags":["suit","formal","style"]},
    {"id":13,"name":"Gaming Mechanical Keyboard","price":179.99,"original_price":229.99,"category":"Electronics","rating":4.9,"reviews":3045,"image":"⌨️","badge":"Gamer Pick","stock":33,"description":"RGB backlit, Cherry MX switches, anti-ghosting, aluminum frame.","tags":["gaming","keyboard","rgb"]},
    {"id":14,"name":"Scented Candle Collection","price":49.99,"original_price":69.99,"category":"Home","rating":4.7,"reviews":2876,"image":"🕯️","badge":"Gift Ready","stock":68,"description":"Set of 6, 40-hour burn time each, natural soy wax, luxury fragrances.","tags":["candle","home","gift"]},
    {"id":15,"name":"Trail Running Shorts","price":44.99,"original_price":64.99,"category":"Sports","rating":4.6,"reviews":1123,"image":"🩳","badge":"Active","stock":47,"description":"4-way stretch, moisture-wicking, zippered pocket, reflective details.","tags":["running","sport","activewear"]},
    {"id":16,"name":"Portable Power Bank 30000mAh","price":79.99,"original_price":109.99,"category":"Electronics","rating":4.8,"reviews":4521,"image":"🔋","badge":"Must Have","stock":61,"description":"Fast charge 65W, 3 USB-C ports, LED display, airline approved.","tags":["charging","portable","travel"]},
]

ORDERS = []
USERS = {"demo@shopverse.com": {"name":"Alex Johnson","password":"demo123","address":"123 Main St, New York, NY 10001"}}

# ── Routes ────────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    featured = PRODUCTS[:8]
    categories = list(set(p['category'] for p in PRODUCTS))
    return render_template('index.html', products=featured, categories=categories, all_products=PRODUCTS)

@app.route('/products')
def products():
    category = request.args.get('category','')
    search   = request.args.get('search','').lower()
    sort     = request.args.get('sort','featured')
    filtered = PRODUCTS
    if category: filtered = [p for p in filtered if p['category']==category]
    if search:   filtered = [p for p in filtered if search in p['name'].lower() or search in p['description'].lower()]
    if sort=='price_asc':  filtered.sort(key=lambda x:x['price'])
    elif sort=='price_desc':filtered.sort(key=lambda x:x['price'],reverse=True)
    elif sort=='rating':   filtered.sort(key=lambda x:x['rating'],reverse=True)
    categories = list(set(p['category'] for p in PRODUCTS))
    return render_template('products.html', products=filtered, categories=categories,
                           selected_category=category, search=search, sort=sort)

@app.route('/product/<int:pid>')
def product_detail(pid):
    product = next((p for p in PRODUCTS if p['id']==pid), None)
    if not product: return redirect(url_for('index'))
    related  = [p for p in PRODUCTS if p['category']==product['category'] and p['id']!=pid][:4]
    return render_template('product_detail.html', product=product, related=related)

@app.route('/cart')
def cart():
    cart_items = session.get('cart',[])
    total = sum(p['price']*p['qty'] for p in cart_items)
    return render_template('cart.html', cart_items=cart_items, total=round(total,2))

@app.route('/api/cart/add', methods=['POST'])
def add_to_cart():
    data = request.json
    pid  = data.get('product_id')
    qty  = data.get('qty',1)
    product = next((p for p in PRODUCTS if p['id']==pid), None)
    if not product: return jsonify({'error':'Not found'}),404
    cart = session.get('cart',[])
    existing = next((i for i in cart if i['id']==pid),None)
    if existing: existing['qty'] += qty
    else: cart.append({'id':pid,'name':product['name'],'price':product['price'],'image':product['image'],'qty':qty})
    session['cart'] = cart
    session.modified = True
    return jsonify({'message':'Added to cart','count':sum(i['qty'] for i in cart)})

@app.route('/api/cart/remove', methods=['POST'])
def remove_from_cart():
    pid  = request.json.get('product_id')
    cart = [i for i in session.get('cart',[]) if i['id']!=pid]
    session['cart'] = cart; session.modified = True
    total = sum(p['price']*p['qty'] for p in cart)
    return jsonify({'count':sum(i['qty'] for i in cart),'total':round(total,2)})

@app.route('/api/cart/update', methods=['POST'])
def update_cart():
    pid  = request.json.get('product_id')
    qty  = request.json.get('qty',1)
    cart = session.get('cart',[])
    for item in cart:
        if item['id']==pid: item['qty']=max(1,qty); break
    session['cart']=cart; session.modified=True
    total = sum(p['price']*p['qty'] for p in cart)
    return jsonify({'count':sum(i['qty'] for i in cart),'total':round(total,2)})

@app.route('/api/cart/count')
def cart_count():
    return jsonify({'count':sum(i['qty'] for i in session.get('cart',[]))})

@app.route('/api/wishlist/toggle', methods=['POST'])
def toggle_wishlist():
    pid  = request.json.get('product_id')
    wish = session.get('wishlist',[])
    if pid in wish: wish.remove(pid); added=False
    else: wish.append(pid); added=True
    session['wishlist']=wish; session.modified=True
    return jsonify({'added':added,'count':len(wish)})

@app.route('/wishlist')
def wishlist():
    ids   = session.get('wishlist',[])
    items = [p for p in PRODUCTS if p['id'] in ids]
    return render_template('wishlist.html', items=items)

@app.route('/checkout')
def checkout():
    cart_items = session.get('cart',[])
    if not cart_items: return redirect(url_for('cart'))
    subtotal = sum(p['price']*p['qty'] for p in cart_items)
    shipping = 0 if subtotal>99 else 9.99
    tax      = round(subtotal*0.08,2)
    total    = round(subtotal+shipping+tax,2)
    return render_template('checkout.html', cart_items=cart_items,
                           subtotal=round(subtotal,2), shipping=shipping, tax=tax, total=total)

@app.route('/api/place-order', methods=['POST'])
def place_order():
    data  = request.json
    cart  = session.get('cart',[])
    if not cart: return jsonify({'error':'Empty cart'}),400
    order = {
        'id': str(uuid.uuid4())[:8].upper(),
        'items': cart, 'customer': data,
        'subtotal': sum(p['price']*p['qty'] for p in cart),
        'date': datetime.now().strftime('%B %d, %Y'),
        'status':'confirmed'
    }
    ORDERS.append(order)
    session['cart']=[]; session['last_order']=order; session.modified=True
    return jsonify({'order_id':order['id'],'redirect':'/order-success'})

@app.route('/order-success')
def order_success():
    order = session.get('last_order')
    return render_template('order_success.html', order=order)

@app.route('/api/products/search')
def search_products():
    q = request.args.get('q','').lower()
    results = [p for p in PRODUCTS if q in p['name'].lower()][:8]
    return jsonify(results)

@app.route('/api/products/<int:pid>/reviews', methods=['GET','POST'])
def reviews(pid):
    if request.method=='POST':
        return jsonify({'message':'Review submitted! Thank you.'})
    return jsonify([
        {'user':'Sarah M.','rating':5,'comment':'Absolutely love it! Exceeded all expectations.','date':'Jan 15, 2025'},
        {'user':'James R.','rating':4,'comment':'Great quality, fast shipping. Would buy again.','date':'Jan 10, 2025'},
        {'user':'Priya K.','rating':5,'comment':'Perfect gift! Arrived beautifully packaged.','date':'Dec 28, 2024'},
    ])

if __name__=='__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
